<?php

	header( 'Content-type: text/html; charset=iso-8859-1' );

$mdH = '
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header bg-dark">
				<h5 class="modal-title text-white" id="editaPacienteTitle">Informacion del Paciente</h5>
				<button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">';


	include("Validaciones/query.php");
	  $usr = $_POST["codigo"];
	  $qry = 'SELECT COUNT(*) AS num FROM usuario WHERE nickname = "'.$usr.'"';
	  $rsl =  bd_query($qry);
	  $row = mysqli_fetch_assoc($rsl);

	//Si el codigo existe
	  if ($row["num"] == 1) 
	  {
		  //Extraer codigos de la base de datos
               $qry = "SELECT nickname FROM usuario";
               $rsl = bd_query($qry);

               $arrUsr = array();
               while ($row = mysqli_fetch_assoc($rsl)) 
			   {
                 $arrUsr[] = $row['nickname'];
               }
			   
			   
			   $qry = 'SELECT * FROM usuario WHERE nickname = "'.$usr.'"';
                  $rsl =  bd_query($qry);
                  $row = mysqli_fetch_assoc($rsl);
				  
			   $mdMD = '
			   
			          <!-- Form newUsuario -->
						<form id="SubirUE" action="Validaciones\modificarUsuario.php" method="post" onsubmit="return validarModificarUsuario("'.json_encode($arrUsr).'");" >  
						
						  <div class="form-group">
							<label style="font-weight: bold;" for="nomUE">Nombre</label>
							<input value="'.$row["nombre"].'" type="text" name="nomUE" id="nomUE" class="input" placeholder="Ej: Juan Carlos" required/>
						  </div>
						  
						  <div class="form-group">
							<label style="font-weight: bold;" for="apePatUE">Apellido Paterno</label>
								<input value="'.$row["apellidoP"].'" type="text" name="apePatUE" id="apePatUE" class="input" placeholder="Ej: Perez" required />
						  </div>
						  
						  <div class="form-group">
							<label style="font-weight: bold;" for="apeMatUE">Apellido Materno</label>
								<input value="'.$row["apellidoM"].'" type="text" name="apeMatUE" id="apeMatUE" class="input" placeholder="Ej: Castro"/>
						  </div>
						  
						  <div class="form-group">
							<label style="font-weight: bold;" for="nickE">Nickname</label>
								<input value="'.$row["nickname"].'" type="text" name="nickE" id="nickE" class="input" placeholder="Nickname" required/>
								<input type="hidden" name="nickActE" id="nickActE" value="'.$usr.'">
						 </div>
					  
						  <div class="form-group">
							<label style="font-weight: bold;" for="tpoUE">Tipo Usuario</label>
							<select id="tpoUE" name="tpoUE" class="input">';
							
									
					  $qry = "SELECT * FROM tipo";
					  $rsl = bd_query($qry);
					  while ($row = mysqli_fetch_assoc($rsl)) 
					  {
					
						$mdMD.= '<option value="'.$row["idTipo"].'">'.$row["tipo"].'</option>';
									
									
				      }
									
									
					$mdMD.='			
							 </select>
						  </div>
						  
						  <div class="form-group">
							<label style="font-weight: bold;" for="passE">Contraseña</label>
								<input type="password" name="passE" id="passE" class="input" placeholder="ingresa una contraseña" />
						  </div>
						  
						  <div class="form-group">
							<label style="font-weight: bold;" for="passRepE">Repite Contraseña</label>
								<input type="password" name="passRepE" id="passRepE" class="input" placeholder="Ingresa de nuevo la contraseña" />
						  </div>';
			   
			   
	  }
	  else
	  {
		$mdMD = "no Puedes Hacer eso, Intenta Selecionar un Registro";
	  }
	


$mdF = '			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
			<button form="SubirUE" type="submit" class="btn btn-primary">Guardar Cambios</button>
		  </div>
	  
	  <!-- Termina Form Edita Paciente -->
		</form>
	  
	  
    </div>
  </div>';
  
  echo $mdH.$mdMD.$mdF;










?>