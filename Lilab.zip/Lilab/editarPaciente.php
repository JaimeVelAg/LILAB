
<?php

	header( 'Content-type: text/html; charset=iso-8859-1' );
	$mdH = '
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header bg-dark">
				<h5 class="modal-title text-white" id="editaPacienteTitle">Informacion del Paciente</h5>
				<button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">';

  $cod = $_POST["codigo"];

  //Si existe el codigo
  include("Validaciones/query.php");
  $qry = 'SELECT COUNT(*) AS existe FROM paciente WHERE codigoPaciente = "'.$cod.'"';
  $res = bd_query($qry);
  if (mysqli_fetch_assoc($res)["existe"] == 1) 
  {
	  $qry = 'SELECT * FROM paciente WHERE codigoPaciente = "'.$cod.'"';
	  $res = bd_query($qry);
	  $row = mysqli_fetch_assoc($res);
	  
	  $mdMD = '
            

	  
	  <!-- Form Edita Paciente -->
            <script src="Validaciones/validarEditarPaciente.js"></script>
            <!-- Formulario -->
       <form action="Procesar/modificarPaciente.php" id="SubirE" method="POST" enctype="multipart/form-data" onsubmit="return validarEditarPaciente()">
		
		  <div class="form-group">
			<label style="font-weight: bold;" for="nombrePaciente">Nombre</label>
			<input type="text" class="form-control" id="nomE" name="nomE" placeholder="Nombre(s)" value="'.$row["nombre"].'">
		  </div>
		  
		  <div class="form-group">
			<label style="font-weight: bold;" for="apellidoPaterno">Apellido Paterno</label>
			<input type="text" class="form-control" id="apePatE" name="apePatE" placeholder="Apellido Paterno" value="'.$row["apellidoP"].'">
		  </div>
		  
		  <div class="form-group">
			<label style="font-weight: bold;" for="apellidoMaterno">Apellido Materno</label>
			<input type="text" class="form-control" id="apeMatE" name="apeMatE" placeholder="Apellido Materno" value="'.$row["apellidoM"].'">
		  </div>
		  
		  <div class="form-group">
			<label style="font-weight: bold;" for="telefono">Telefono</label>
			<input type="text" class="form-control" id="telE" name="telE" placeholder="Telefono" value="'.$row["telefono"].'">
		  </div>
	  
		  <div class="form-group">
			
			   <div class="archivo paciente">
               <p class="textCenter" style="margin-top:2px; font-weight: bold;">Codigo de Paciente</p>
              <label style="font-weight: bold; padding: 20px; border: 1px solid #000; background: #acef9f;" id="cod">'.$row["codigoPaciente"].'</label>
              <input type="hidden" name="codigoE" value="'.$row["codigoPaciente"].'">
             </div>
	  
		  </div>';

  }
  else 
  {
	  $mdMD = "no Puedes Hacer eso, Intenta Selecionar un Registro";
  }

   $mdF = '			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
			<button form="SubirE" type="submit" class="btn btn-primary">Guardar Cambios</button>
		  </div>
	  
	  <!-- Termina Form Edita Paciente -->
		</form>
	  
	  
    </div>
  </div>';
  
  echo $mdH.$mdMD.$mdF;
?>