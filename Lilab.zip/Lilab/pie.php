<!-- Ejemplo de mision y vision -->
<div class="container">
  <h2>¿Quienes somos?</h2>
  <p>El renovado Laboratorio de Análisis Clínicos LILAB, tiene como objetivo esencial brindar de manera eficiente, oportuna y certera todo tipo de exámenes médicos que el paciente requiera en área de Bioquímica, Hematología, Parasitología, Bacteriología, Inmunología y Hormonas. Además, tenemos la ventaja de realizar exámenes de urgencia como Perfil Hematológico, PCR, Orina Completa y Test rápidos para la detección de enfermedades respiratorias, los cuales son entregados durante el día. Con profesionales altamente capacitados y tecnología de punta otorgamos confiabilidad en cada procedimiento. </p>
  <p> De la misma forma nuestros procesos son evaluados periódicamente por medio de controles de calidad externos, sumados a los efectuados diariamente por nuestros profesionales. </p>
  <p> Laboratorio LILAB cuenta con un moderno centro de operaciones, lo que permite a los pacientes acceder cómoda y oportunamente a los servicios que brinda nuestro laboratorio. Además, cuenta con una amigable plataforma Web para la descarga de resultados y resolver distintas consultas acerca de nuestros servicios. </p>
  <br>
  <div class="row">
    <div class="bg-primary text-light col-md-6">
      <h3>Mision</h3>
      <p> LiLab Laboratorios tienen como misión el contribuir con el mejoramiento de la calidad de vida del la población costarricense, a través del suministro de ayudas diagnósticas que satisfacen las exigencias de la medicina moderna, proporcionando resultados confiables y oportunos con el más alto desarrollo profesional, tecnológico y de servicio. </p>
	  </div>
    <div class="col-md-6">
      <h3>Vision</h3>
      <p>Proyectamos un crecimiento de nuestra empresa, acorde a nuestra importante trayectoria y lo que hemos consolidado en años de funcionamiento. Nuestro objetivo es constituirnos en el Laboratorio Clínico preferido, reconocido por su excelencia en servicio y calidad.</p>
    </div>
  </div>
</div>
<br>
</div>

<!-- Footer c: con responsividad -->
<footer id="pie">
<div id="Encuentranos" class="footer-top">
<div class="container">
  <div class="row">
    <div class="col-md-4 col-sm-12 col-xs-12 segment-one">
      <h3>Ponte en contacto</h3>
      <p>Tel: 314-15-88</p>
      <p>Tambien puedes encontrarnos en nuestras redes sociales</p>
      <a href="#"><i class="icono icono-phone text-white"></i></a>
      <a href="#"><i class="icono icono-facebook text-white"></i></a>
      <a href="#"><i class="icono icono-instagram text-white"></i></a>
      <a href="#"><i class="icono icono-whatsapp text-white"></i></a> <br>

	  <h3 style="margin-top: 18%;">Horario de Atencion</h3>
      <p>Lunes a Sabado</p>
      <p>8:00am - 2:00pm</p>
      <p>5:00am - 7:00pm</p>
    </div>

     <div class="col-md-4 col-sm-12 col-xs-12 segment-two">
       <h3>Encuentranos <i class="icono icono-location"></i></h3>
       <a href="#"></a>
       <p>Av. Maestro 773 Int.2 - Col. Lomas de Hidalgo - C.P. 58240 - Morelia, Michoacán</p>
       <div class="frame">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7511.565638035561!2d-101.19003317055822!3d19.72186844327915!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842d0e40be8f4d3b%3A0xf001c256ae856856!2sInstituto%20Tecnol%C3%B3gico%20de%20Morelia!5e0!3m2!1ses-419!2smx!4v1571029763649!5m2!1ses-419!2smx" width="300" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
       </div>
     </div>

<!-- Contactanos -->
<script src="Validaciones/validarContactanos.js"></script>
 <div class="col-md-4 col-sm-12 col-xs-12 segment-three">
   <h3>Contactanos</h3>
   <form class="formulario" method="post" action="nuevobuzon.php" name="buzon" id="buzon" onsubmit="return validarContactanos()">
     <input type="text" name="nombre" id="nom" placeholder="Tu nombre" required>
     <input type="tel" name="telefono" id="tel" placeholder="Numero de telefono" required>
     <input type="email" name="correo" id="email" placeholder="Correo(Opcional)">
     <br>
     <textarea type="text" style="height:100px;" name="mensaje" id="sms" placeholder="Tu mensaje" required></textarea>
     <br>
     <button class="btn btn-dark" type="submit" >Enviar</button>
   </form>
 </div>

  </div>
</div>
</div>
<p class="footer-bottom-text">Todos los derechos reservados por &copy;LiLab 2019</p>
</footer>
<!-- Implementacion del jQuery para algunas herramientas de bootstrap -->



<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="principal_js/jquery.js"></script>
<script src="principal_js/bootstrap.min.js"></script>

<!-- JQuery -->
            <script
              src="https://code.jquery.com/jquery-3.4.1.min.js"
              integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
              crossorigin="anonymous">
            </script>

            <!-- Mostrar Lista PDF -->
            <script type="text/javascript">
              $(function (){
                var btnRlt = $('#verRlt');
                btnRlt.on('click', function(e){
                  cod = document.getElementById("codigo").value.trim();
                  if (cod != "") {
                    var ajax = $.ajax({
                      data: {cod},
                      url: "descargar.php",
                      type: 'POST',
                      success: function (response){
                        document.getElementById("tablaResultados").innerHTML = "";
                        document.getElementById("tablaResultados").innerHTML = response;
                      },
                      error: function(response, status, error){
                        alert("Error al conectar, reintente de nuevo");
                      }
                    })
                  } else {
                    alert("Ingrese un codigo")
                    document.getElementById("tablaResultados").innerHTML = "";
                  }
                })
              })


                  /*

                  if (cod != "") {
                    alert("Si we")
                    var ajax = $.ajax({
                      data: {cod},
                      url: "descargar.php",
                      type: 'POST',
                      success: function (response){
                        if (response == "false")
                          alert("El codigo introducido no es valido, por favor verifique el codigo o pongase en contacto con nosotros");
                        else
                          window.open(response,'Analisis Clinico');
                      },
                      error: function(response, status, error){
                        alert("Error al conectar, reintente de nuevo");
                      }
                      else {
                        alert("Ingrese un codigo")
                      }*/
            </script>

</body>
</html>
