<?php
	header( 'Content-type: text/html; charset=iso-8859-1' );
	$servername = "localhost";
    $username = "root";
  	$password = "root";
  	$dbname = "lilab2";

	$conn = new mysqli($servername, $username, $password, $dbname);
      if($conn->connect_error){
        die("Conexión fallida: ".$conn->connect_error);
      }

    $salida = "";

    $query = "SELECT * FROM anuncio WHERE titulo NOT LIKE '' ORDER By fecha desc";

    if (isset($_POST['consulta'])) {
    	$q = $conn->real_escape_string($_POST['consulta']);
    	$query = "SELECT * FROM anuncio WHERE titulo LIKE '$q%' OR fecha LIKE '$q%' OR descripcion LIKE '$q%'";
    }

    $resultado = $conn->query($query);

    if ($resultado->num_rows>0) {
    	$salida.='

		<table class="table  textCenter bg-white miScroll" style="margin-top: 2%; width:100%;">

			<thead style="width:100%; background:#5d97e2;">
			  <tr id="headTR">
				<th scope="col">ID</th>
				<th scope="col">Titulo</th>
				<th scope="col">Fecha</th>
				<th scope="col">Descripcion</th>
				<th scope="col">Carrusel</th>
				<th scope="col">Cuerpo</th>
			  </tr>
			</thead>
			<tbody>';


    	while ($fila = $resultado->fetch_assoc())
		{
    		$salida.=	"
				<tr class='aHover1' id='".$fila['id_anuncio']."' onclick='seleccionarPublicacion(this);'  >
					<th scope='row'> ".$fila['id_anuncio']." </th>
					<td style=' word-break: break-word; ' > ".$fila['titulo']." </td>
					<td style=' word-break: break-word; width: 120px;'> ".$fila['fecha']."</td>
					<td style=' word-break: break-word; ' > ".$fila['descripcion']." </td>
					<td style=' word-break: break-word; ' ><a class='link' href='".$fila['img_1']."'> IMG Carrusel </td>
					<td style=' word-break: break-word; ' ><a class='link' href='".$fila['img_2']."'> IMG Body </td>
				</tr>";

				/*
				<tr class="aHover1" >
					<th scope="row">1</th>
					<td>2x1</td>
					<td>mucho</td>
					<td><a href="#" class="link">carrucel.jpg</a></td>
					<td><a href="#" class="link">cuerpo.jpg</a></td>
				  </tr>
				  */

    	}
    	$salida.="</tbody></table>";
    }
	else
	{
    	$salida.="NO ENCONTRAMOS PUBLICACIONES :(";
    }


    echo $salida;

    $conn->close();



?>
