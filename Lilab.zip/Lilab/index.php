<?php
  include('bd.php');
  include('head.php');
  include('cabecera.php');
  include('carrusel.php');
  include('pie.php');
?>
