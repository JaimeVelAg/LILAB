$(editaPublicacion());

function editaPublicacion(codigo)
{
	
	
	
	$.ajaxSetup({
		'beforeSend' : function(xhr) {
		try{
		xhr.overrideMimeType('text/html; charset=UTF-8');
		}
		catch(e){
		 
		 
		}
		}});
	
	
	
	
	
	$.ajax({
		url: 'editaPublicacion.php' ,
		type: 'POST' ,
		dataType: 'html',
		data: {codigo: codigo},
	})
	.done(function(respuesta){
		$("#editaPublicacion").html(respuesta);
	})
	.fail(function(){
		console.log("error");
	});
}

function editarPublicacion()
{
	
	var valor = document.getElementById("valueModificarPublicacion").value;
	
	if (valor != "") 
	{
		editaPublicacion(valor);
	}else{
		editaPublicacion();
	}
}