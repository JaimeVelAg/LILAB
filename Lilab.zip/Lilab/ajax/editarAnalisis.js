$(editaAnalisis());

function editaAnalisis(codigo, id)
{
	
	$.ajaxSetup({
		'beforeSend' : function(xhr) {
		try{
		xhr.overrideMimeType('text/html; charset=UTF-8');
		}
		catch(e){
		 
		 
		}
		}});
	
	
	$.ajax({
		cache: false,
		url: 'editarAnalisis.php',
		type: 'POST',
		dataType: 'html',
		data: {codigo: codigo, id: id},
	})
	.done(function(respuesta){
		$("#editaAnalisis").html(respuesta);
	})
	.fail(function(){
		console.log("error");
	});
}

function editarAnalisis()
{
	
	var varCodigo = document.getElementById("valueModificarPaciente").value;
	var varId = document.getElementById("valueModificarAnalisis").value;
	
	if (varCodigo != "" && varId != "") 
	{
		editaAnalisis(varCodigo, varId);
	}else{
		editaAnalisis();
	}
}
