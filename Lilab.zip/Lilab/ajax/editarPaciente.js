$(editaPaciente());

function editaPaciente(codigo)
{
	
	$.ajaxSetup({
		'beforeSend' : function(xhr) {
		try{
		xhr.overrideMimeType('text/html; charset=UTF-8');
		}
		catch(e){
		 
		 
		}
		}});
	
	
	
	
	$.ajax({
		url: 'editarPaciente.php' ,
		encoding:"UTF-8",
		type: 'POST' ,
		dataType: 'html',
		data: {codigo: codigo},
	})
	.done(function(respuesta){
		$("#editaPaciente").html(respuesta);
	})
	.fail(function(){
		console.log("error");
	});
}

function editarPaciente()
{
	
	var valor = document.getElementById("valueModificarPaciente").value;
	
	if (valor != "") 
	{
		editaPaciente(valor);
	}else{
		editaPaciente();
	}
}
