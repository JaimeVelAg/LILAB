<?php
	include('bd.php');
	$id=$_GET['cod'];
	$query='DELETE FROM anuncio
			WHERE id_anuncio="'.$id.'" ';
	bd_consulta($query);
	
	SESSION_START();
  switch($_SESSION['tipo'])
  {
	  case "Administrador":
		header('Location: indexAdmin.php?state=-3');
		break;
		
	  case "Quimico":
		echo "No seas Travieso";
		break;
		
	  case "Publicitario":
		header('Location: indexPublicitario.php?state=-3');
		break;
	  
  }

?>
