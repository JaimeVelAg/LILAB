<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>LiLab</title>
    <!-- Metaviewport para el responsive -->
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <!-- LLamado al bootstrap local -->
    <link rel="stylesheet" href="principal_css/bootstrap.min.css">
    <link rel="stylesheet" href="principal_css/style.css">
    <link rel="stylesheet" href="principal_css/font.css">
    <link rel="stylesheet" href="principal_css/font-2.css">
    <link rel="stylesheet" href="principal_css/main.css">
    <!-- Custom styles for this template -->

  </head>
