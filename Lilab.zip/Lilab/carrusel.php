<?php
  $query="SELECT * FROM anuncio order by fecha";
  $resul=bd_consulta($query);
?>
<div class="container">

      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <?php
            for($i=0;$row=mysqli_fetch_assoc($resul);$i++){
              if($i==0){
                echo "<li data-target="."#carouselExampleIndicators" ."data-slide-to=".$i." class="."active"."></li>";
              }
              else{
                echo "<li data-target="."#carouselExampleIndicators" ."data-slide-to=".$i."></li>";
              }
            }
          ?>
          <!--<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>-->
        </ol>

      <div class="carousel-inner">

        <?php
		$query = "SELECT img_1, id_anuncio FROM anuncio WHERE img_1 != ''";
        $resul=bd_consulta($query);
        for($i=0;$row=mysqli_fetch_assoc($resul);$i++){
            if($i==0){
              $first='<div class="carousel-item active">
                <img class="d-block w-100" src="';
            }
            else{
              $first='<div class="carousel-item">
                <img class="d-block w-100" src="';
            }
            $img="" .$row['img_1'];
            $last='" alt="Second slide">
            <div class="carousel-caption d-md-block">
              <button type="button" class="btn btn-primary" name="button" style="width:100px;"><a style="text-decoration: none;" class="btn-primary" href="index.php#'.$row['id_anuncio'] .'P">Ver más</a></button>
            </div>
            </div>';
           echo ($first .$img .$last);
        }
        ?>

      </div>

      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

    </div>
</div>

<div class="container bg-white card border-0 shadow my-5">
    <!-- saltos de linea para que se vea bien el carrusel -->
    <br>

    <?php
	  $que = "SELECT * FROM anuncio WHERE img_2 != '' AND titulo != '' AND descripcion != '' ORDER BY fecha DESC";
      $resl=bd_consulta($que);
      for($i=0;$row=mysqli_fetch_assoc($resl);$i++)
	  {

        if($i%2 == 0){
          //echo "Par";

		  if($row['img_2'] != "")
		  {
			  $res='
			  <hr id="'.$row['id_anuncio'] .'P">
			  <br>
			  <div class="container">
				<section class="main row">
				  <article class="col-md-7">
					<h1>' .$row['titulo'] .'</h1>
					<p style="white-space: pre-line;">' .$row['descripcion'] .'</p>
				  </article>
				  <aside class="col-md-5">
					<img src="' .$row['img_2'] .'" class="d-block w-100" style="max-width:350px;" alt="...">
				  </aside>
				</section>
			  </div>';
		  }
		  else
		  {
			  $res='
			  <hr  id="'.$row['id_anuncio'] .'P" >
			  <br>
			  <div class="container">
				<section class="main row">
				  <article class="col-md-7">
					<h1>' .$row['titulo'] .'</h1>
					<p style="white-space: pre-line;">' .$row['descripcion'] .'</p>
				  </article>
				  <aside class="col-md-5">
				  </aside>
				</section>
			  </div>';
		  }
          echo($res);
        }
        else
		{
          if($row['img_2'] != "")
		  {
			  $res='<br>
			  <hr id="'.$row['id_anuncio'] .'P" >
			  <br>
			  <div class="container">
				<section class="main row">
				  <aside class="col-md-5">
					<img style="max-width:350px;" src="' .$row['img_2'] .'" alt="" class="d-block w-100">
				  </aside>
				  <article class="col-md-7">
					<h1>' .$row['titulo'] .'</h1>
					<p style="white-space: pre-line;">' .$row['descripcion'] .'</p>
				  </article>
				</section>
			  </div>
			  ';
		  }
		  else
		  {
			  $res='<br>
			  <hr id="'.$row['id_anuncio'] .'P" >
			  <br>
			  <div class="container">
				<section class="main row">
				  <aside class="col-md-5"><img style="max-width:350px;" src="' .$row['img_2'] .'" alt="" class="d-block w-100">
				  </aside>
				  <article class="col-md-7">
					<h1>' .$row['titulo'] .'</h1>
					<p style="white-space: pre-line;">' .$row['descripcion'] .'</p>
				  </article>
				</section>
			  </div>
			  ';
		  }
          echo($res);

        }

      }
    ?>
    <!-- PAQUETE INFANTIL EJEMPLO -->
    <!--<div class="container">
      <section class="main row">
        <article class="col-md-7">
          <h1>Paquete para niños</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </article>
        <aside class="col-md-5">
          <img src="img/p11.jpg" class="d-block w-100" alt="...">
        </aside>
      </section>
    </div>
    <br>
    <hr>
    <br>


    <div class="container">
      <section class="main row">
        <aside class="col-md-5">
          <img src="img/p22.jpg" alt="" class="d-block w-100">
        </aside>
        <article class="col-md-7">
          <h1>Analisis rutina</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </article>
      </section>
    </div>
    <br>
    <hr>
    <br>
-->

    <div id="quienes">

    </div>
    <br><br><hr><br>
