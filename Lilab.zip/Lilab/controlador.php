<?php
	include('bd.php');
	include('miEncabezado.php');
	$miMensaje="";

	if(!$_SESSION['userOK'])
	{
		include('LoginLiLab.html');
	}
	else
	{
		echo $_SESSION['tipo'];
		
		/*
		  switch($_SESSION['tipo'])
		  {
			  case "Administrador":
				include('indexAdmin.php');
				break;
				
			  case "Quimico":
				include('indexQuimico.php');
				break;
				
			  case "Publicitario":
				include('indexPublicitario.php');
				break;
			  
		  }
		  */
	}
?>